package com.cg.bankaccount.dao;

public interface IBankDao 
{
	//interface methods
public void createAccount(long AccNo,String Name,long phoneno,Double balance);           
public void showBalance(long AccNo);
public void  deposit(long AccNo,double deposit);
public void  withdraw(long AccNo,double withdraw);
public void  fundtransfer(long AccNo1,long AccNo2,double fundamt);
public void  display();

}
