package com.cg.bankaccount.testing;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;

import com.cg.bankaccount.bean.Account;

/*public class ClassTest {
	
/*	public static Account account;
@BeforeClass
	public static void Beforeclass()
	{
	account=new Account();
	}
*/