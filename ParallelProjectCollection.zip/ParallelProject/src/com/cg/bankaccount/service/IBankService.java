package com.cg.bankaccount.service;

public interface IBankService
{
	     //service interface methods
	public void createAccount(long AccNo,String Name,long phoneno,Double balance);
	public void showBalance(long AccNo);
	public void  deposit(long AccNo,double deposit);
	public void  withdraw(long AccNo,double withdraw);
	public void  fundtransfer(long AccNo1,long AccNo2,double fundamt);
	public boolean validateName(String name);
	public boolean validateContactNumber(long phoneno);
	public void  display();
	

}
